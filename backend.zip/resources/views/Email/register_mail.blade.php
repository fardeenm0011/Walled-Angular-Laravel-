<b>Dear {{$name}}</b>

<p>
	We are delighted to inform that your account has been activated. 
	Please use your registered email address and given one time password to login.<br/>
	URL: http://atavismpanel.com/<br/>
	Email: {{$email}}<br/>
	Password: {{$password}}<br/>
</p>

<p>
<b>Best Regards,</b><br/>
Team Atavism
</p>