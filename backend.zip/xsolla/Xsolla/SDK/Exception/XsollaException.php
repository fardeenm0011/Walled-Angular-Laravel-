<?php

namespace Xsolla\SDK\Exception;

class XsollaException extends \RuntimeException
{
}
