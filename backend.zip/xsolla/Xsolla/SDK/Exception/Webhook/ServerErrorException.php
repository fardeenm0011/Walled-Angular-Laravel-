<?php

namespace Xsolla\SDK\Exception\Webhook;

class ServerErrorException extends XsollaWebhookException
{
}
