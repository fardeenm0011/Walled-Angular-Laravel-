<?php

namespace Xsolla\SDK\Exception\API;

class UnprocessableEntityException extends XsollaAPIException
{
}
