<?php

namespace Xsolla\SDK\Exception\API;

class AccessDeniedException extends XsollaAPIException
{
}
