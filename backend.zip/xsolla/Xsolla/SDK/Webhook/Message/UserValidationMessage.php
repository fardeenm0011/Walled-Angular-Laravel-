<?php

namespace Xsolla\SDK\Webhook\Message;

class UserValidationMessage extends Message
{
}
