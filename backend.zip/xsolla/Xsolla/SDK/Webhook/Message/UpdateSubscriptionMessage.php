<?php

namespace Xsolla\SDK\Webhook\Message;

class UpdateSubscriptionMessage extends CancelSubscriptionMessage
{
}
