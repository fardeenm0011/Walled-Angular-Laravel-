<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderProduct extends Model {

    protected $table="josgt_eshop_orderproducts";
    
}