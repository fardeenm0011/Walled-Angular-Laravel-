<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discord extends Model
{
    protected $table="josgt_discord";

    public $timestamps = false;
}
