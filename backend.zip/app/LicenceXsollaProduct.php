<?php
        
namespace App;

use Illuminate\Database\Eloquent\Model;

class LicenceXsollaProduct extends Model {

    protected $table="josgt_licences_xsolla_products";
   
}