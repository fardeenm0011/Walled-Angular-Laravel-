<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LicenceCcuHistory extends Model
{
	protected $primaryKey = 'id';

    protected $table="josgt_licences_ccu_history";
    
}
