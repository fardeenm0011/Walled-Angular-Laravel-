<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Release extends Model
{
    protected $table="josgt_releases";

    public $timestamps = false;
}
