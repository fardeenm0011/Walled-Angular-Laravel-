<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PoolFeature extends Model
{
    //
    /*public function requests()
    {
        return $this->hasOne('App\FeatureRequests');
    }*/
    /*public function requests()
    {
        return $this->belongsTo('App\FeatureRequests','App\PoolFeature');
    }*/
}
