import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-advisor',
  templateUrl: './view-advisor.component.html',
  styleUrls: ['./view-advisor.component.scss']
})
export class ViewAdvisorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
